# ATM-Software-CPP-SFML-March-2015-

![Alt text](https://github.com/RazvanBarbosul/ATM-Software-CPP-SFML-March-2015-/blob/master/Capture1.PNG?raw=true "Capture1.PNG")
![Alt text](https://github.com/RazvanBarbosul/ATM-Software-CPP-SFML-March-2015-/blob/master/Capture2.PNG?raw=true "Capture2.PNG")
![Alt text](https://github.com/RazvanBarbosul/ATM-Software-CPP-SFML-March-2015-/blob/master/Capture3.PNG?raw=true "Capture3.PNG")
![Alt text](https://github.com/RazvanBarbosul/ATM-Software-CPP-SFML-March-2015-/blob/master/Capture4.PNG?raw=true "Capture4.PNG")
